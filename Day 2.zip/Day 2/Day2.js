var a=50;
var b=20;
var sum = a+b;
document.write("sum = "+ sum);
